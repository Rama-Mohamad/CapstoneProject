package com.example.porjctse2026

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()

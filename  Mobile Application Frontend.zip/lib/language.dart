class AppLanguage {
  static bool isArabic = false;
}

import 'package:flutter/material.dart';

import 'package:porjctse2026/language.dart';

import 'AdminCreatAccount.dart';

import 'gateUserPage.dart';

import 'securityPage.dart';

import 'package:http/http.dart' as http;

import 'dart:convert';

void main() {
  runApp(MyApp());
}

class MyApp extends StatefulWidget {
  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  void refreshApp() {
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: LoginPage(
        onLanguageChanged: refreshApp,
      ),
    );
  }
}

class LoginPage extends StatefulWidget {
  final VoidCallback? onLanguageChanged;

  const LoginPage({super.key, this.onLanguageChanged});

  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  TextEditingController emailController = TextEditingController();

  TextEditingController passwordController = TextEditingController();

  bool isArabic = AppLanguage.isArabic;

  bool isPasswordHidden = true;

  String emailError = "";

  String passwordError = "";

  Future<void> login() async {
    setState(() {
      emailError = "";

      passwordError = "";
    });

    String email = emailController.text.trim();

    String pass = passwordController.text.trim();

    if (!email.endsWith("@upm.edu.sa")) {
      setState(() {
        emailError = isArabic
            ? "يجب استخدام بريد الجامعة"
            : "Use university email (@upm.edu.sa)";
      });

      return;
    }

    try {
      final response = await http.post(
        Uri.parse(
            "https://ad8ae53d-1dc3-46ba-ba15-9d1076f33826-00-2h49r1p41eomw.janeway.replit.dev/api/login"),
        headers: {
          "Content-Type": "application/json",
        },
        body: jsonEncode({
          "email": email,
          "password": pass,
        }),
      );

      final data = jsonDecode(response.body);

      if (response.statusCode != 200) {
        setState(() {
          passwordError =
              isArabic ? "بيانات الدخول غير صحيحة" : "Invalid login";
        });

        return;
      }

      String role = data["role"];

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(isArabic ? "تم تسجيل الدخول" : "Login Success"),
        ),
      );

      Widget nextPage;

      if (role == "admin") {
        nextPage = AdminCreateAccount(
          isArabic: AppLanguage.isArabic,
        );
      } else if (role == "ahsanrahman") {
        nextPage = GateUserPage();
      } else if (role == "gate") {
        nextPage = GateUserPage();
      } else if (role == "sec") {
        nextPage = SecurityPage();
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Unknown role ❌")),
        );

        return;
      }

      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => nextPage),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text("Server error ❌"),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    isArabic = AppLanguage.isArabic;

    return Scaffold(
      backgroundColor: Color(0xffe9e9e9),
      body: Stack(
        children: [
          Container(
            height: 320,
            decoration: BoxDecoration(
              color: Colors.black,
              borderRadius: BorderRadius.only(
                bottomLeft: Radius.circular(120),
              ),
              boxShadow: [
                BoxShadow(
                  color: Colors.black26,
                  blurRadius: 20,
                  offset: Offset(0, 10),
                )
              ],
            ),
          ),

          /// CONTENT

          SingleChildScrollView(
            child: Column(
              children: [
                SizedBox(height: 140),

                /// WELCOME

                Column(
                  children: [
                    Text(
                      isArabic ? "مرحبا" : "Welcome",
                      style: TextStyle(
                        fontSize: 48,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                    SizedBox(height: 10),
                    Text(
                      isArabic ? "Welcome" : "مرحبا",
                      style: TextStyle(
                        fontSize: 40,
                        color: Colors.white70,
                      ),
                    ),
                  ],
                ),

                SizedBox(height: 120),

                /// EMAIL

                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 30),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        isArabic ? "البريد الإلكتروني" : "Email",
                        style: TextStyle(color: Colors.grey, fontSize: 18),
                      ),
                      SizedBox(height: 10),
                      Container(
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(15),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black26,
                              blurRadius: 10,
                              offset: Offset(0, 5),
                            )
                          ],
                        ),
                        child: TextField(
                          controller: emailController,
                          decoration: InputDecoration(
                            border: InputBorder.none,
                            contentPadding: EdgeInsets.symmetric(
                                horizontal: 20, vertical: 16),
                          ),
                        ),
                      ),
                      if (emailError != "")
                        Padding(
                          padding: EdgeInsets.only(top: 8),
                          child: Text(
                            emailError,
                            style: TextStyle(color: Colors.red, fontSize: 14),
                          ),
                        )
                    ],
                  ),
                ),

                SizedBox(height: 30),

                /// PASSWORD

                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 30),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        isArabic ? "كلمة المرور" : "Password",
                        style: TextStyle(color: Colors.grey, fontSize: 18),
                      ),
                      SizedBox(height: 10),
                      Container(
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(15),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black26,
                              blurRadius: 10,
                              offset: Offset(0, 5),
                            )
                          ],
                        ),
                        child: TextField(
                          controller: passwordController,
                          obscureText: isPasswordHidden,
                          decoration: InputDecoration(
                            border: InputBorder.none,
                            contentPadding: EdgeInsets.symmetric(
                                horizontal: 20, vertical: 16),
                            suffixIcon: IconButton(
                              icon: Icon(
                                isPasswordHidden
                                    ? Icons.visibility_off
                                    : Icons.visibility,
                                color: Colors.grey,
                              ),
                              onPressed: () {
                                setState(() {
                                  isPasswordHidden = !isPasswordHidden;
                                });
                              },
                            ),
                          ),
                        ),
                      ),
                      if (passwordError != "")
                        Padding(
                          padding: EdgeInsets.only(top: 8),
                          child: Text(
                            passwordError,
                            style: TextStyle(color: Colors.red, fontSize: 14),
                          ),
                        )
                    ],
                  ),
                ),

                SizedBox(height: 50),

                /// LOGIN BUTTON

                GestureDetector(
                  onTap: login,
                  child: Container(
                    width: 200,
                    height: 50,
                    decoration: BoxDecoration(
                      color: Colors.black,
                      borderRadius: BorderRadius.circular(25),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black38,
                          blurRadius: 10,
                          offset: Offset(0, 5),
                        )
                      ],
                    ),
                    child: Center(
                      child: Text(
                        isArabic ? "تسجيل الدخول" : "Login",
                        style: TextStyle(color: Colors.white, fontSize: 20),
                      ),
                    ),
                  ),
                ),

                SizedBox(height: 20),

                Text(
                  isArabic ? "نسيت كلمة المرور؟" : "Forgot Password?",
                  style: TextStyle(color: Colors.grey),
                ),

                SizedBox(height: 50),
              ],
            ),
          ),

          /// LANGUAGE BUTTON

          Positioned(
            top: 50,
            right: 20,
            child: GestureDetector(
              behavior: HitTestBehavior.opaque,
              onTap: () {
                setState(() {
                  AppLanguage.isArabic = !AppLanguage.isArabic;

                  isArabic = AppLanguage.isArabic;
                });

                widget.onLanguageChanged?.call();
              },
              child: Padding(
                padding: EdgeInsets.all(10),
                child: Row(
                  children: [
                    Text(
                      isArabic ? "En" : "عربي",
                      style: TextStyle(color: Colors.white, fontSize: 16),
                    ),
                    SizedBox(width: 6),
                    Icon(Icons.language, color: Colors.white)
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

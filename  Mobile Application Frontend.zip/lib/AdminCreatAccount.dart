import 'package:flutter/material.dart';
import 'adminListUsers.dart';
import 'language.dart';

class AdminCreateAccount extends StatefulWidget {
  final bool isArabic;
  AdminCreateAccount({required this.isArabic});
  @override
  _AdminCreateAccountState createState() => _AdminCreateAccountState();
}

class _AdminCreateAccountState extends State<AdminCreateAccount> {
  final fullNameController = TextEditingController();
  final emailController = TextEditingController();
  final passwordController = TextEditingController();
  final confirmPasswordController = TextEditingController();
  String? accessLevel;
  String? position;
  String emailError = "";
  String passwordError = "";
  String accessError = "";
  List<String> accessLevels = ["Gate User", "Security"];
  List<String> positions = [
    "Registrar",
    "Vice President",
    "Dean",
    "Head of Department (HOD)",
    "IT Support / IT Administrator"
  ];
  bool validateEmail(String email) {
    return RegExp(r'\S+@\S+\.\S+').hasMatch(email);
  }

  void createAccount() {
    setState(() {
      emailError = "";
      passwordError = "";
      accessError = "";
    });
    if (!validateEmail(emailController.text)) {
      setState(() {
        emailError = widget.isArabic
            ? "البريد الإلكتروني غير صحيح"
            : "Invalid email address";
      });
      return;
    }
    if (passwordController.text != confirmPasswordController.text) {
      setState(() {
        passwordError = widget.isArabic
            ? "كلمات المرور غير متطابقة"
            : "Passwords do not match";
      });
      return;
    }
    if (accessLevel == null) {
      setState(() {
        accessError = widget.isArabic
            ? "يرجى اختيار مستوى الوصول"
            : "Please select access level";
      });
      return;
    }
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        backgroundColor: Colors.green,
        content: Text(
          widget.isArabic
              ? "تم إنشاء الحساب بنجاح"
              : "Account Created Successfully",
        ),
      ),
    );
  }

  void logoutDialog() {
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xfff7f1ff),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(
          top: Radius.circular(28),
        ),
      ),
      builder: (context) {
        return Padding(
          padding: const EdgeInsets.fromLTRB(25, 12, 25, 35),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 70,
                height: 7,
                decoration: BoxDecoration(
                  color: Colors.grey[400],
                  borderRadius: BorderRadius.circular(20),
                ),
              ),
              const SizedBox(height: 45),
              Text(
                widget.isArabic
                    ? "هل أنت متأكد أنك تريد تسجيل الخروج؟"
                    : "Are you sure you want logout?",
                textAlign: TextAlign.center,
                style: const TextStyle(
                  fontSize: 26,
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                ),
              ),
              const SizedBox(height: 45),
              Row(
                children: [
                  Expanded(
                    child: GestureDetector(
                      onTap: () {
                        Navigator.pop(context);
                      },
                      child: Container(
                        height: 65,
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                          color: Colors.grey[300],
                          borderRadius: BorderRadius.circular(18),
                        ),
                        child: Text(
                          widget.isArabic ? "لا" : "No",
                          style: const TextStyle(
                            fontSize: 28,
                            color: Colors.black,
                          ),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 25),
                  Expanded(
                    child: GestureDetector(
                      onTap: () {
                        Navigator.pop(context);
                        Navigator.pop(context);
                      },
                      child: Container(
                        height: 65,
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                          color: Colors.grey[300],
                          borderRadius: BorderRadius.circular(18),
                        ),
                        child: Text(
                          widget.isArabic ? "نعم" : "Yes",
                          style: const TextStyle(
                            fontSize: 28,
                            color: Colors.black,
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        );
      },
    );
  }

  Widget inputBox(controller) {
    return Container(
      margin: EdgeInsets.only(top: 8, bottom: 20),
      padding: EdgeInsets.symmetric(horizontal: 15),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(15),
        boxShadow: [
          BoxShadow(
            color: Colors.black12,
            blurRadius: 10,
            offset: Offset(0, 4),
          )
        ],
      ),
      child: TextField(
        controller: controller,
        decoration: InputDecoration(
          border: InputBorder.none,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    bool isArabic = AppLanguage.isArabic;
    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        title: Text(
          isArabic ? "صفحة المدير - إنشاء حساب" : "Admin Page-Create account",
        ),
        leading: IconButton(
          icon: Icon(
            Icons.logout,
            color: Colors.red,
          ),
          onPressed: logoutDialog,
        ),
      ),
      backgroundColor: Color(0xfff3f3f3),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              isArabic ? "الاسم الكامل" : "Full Name",
            ),
            inputBox(fullNameController),
            Text(
              isArabic ? "البريد الإلكتروني" : "Email",
            ),
            inputBox(emailController),
            if (emailError != "")
              Text(
                emailError,
                style: TextStyle(color: Colors.red),
              ),
            Text(
              isArabic ? "كلمة المرور" : "Password",
            ),
            inputBox(passwordController),
            Text(
              isArabic ? "تأكيد كلمة المرور" : "Confirm Password",
            ),
            inputBox(confirmPasswordController),
            if (passwordError != "")
              Text(
                passwordError,
                style: TextStyle(color: Colors.red),
              ),
            SizedBox(height: 10),
            Text(
              isArabic ? "مستوى الوصول" : "Access level",
            ),
            Container(
              margin: EdgeInsets.only(top: 8, bottom: 20),
              padding: EdgeInsets.symmetric(horizontal: 15),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(15),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black12,
                    blurRadius: 10,
                    offset: Offset(0, 4),
                  )
                ],
              ),
              child: DropdownButtonHideUnderline(
                child: DropdownButton<String>(
                  value: accessLevel,
                  hint: Text(
                    isArabic ? "اختر" : "Select",
                  ),
                  isExpanded: true,
                  items: accessLevels.map((e) {
                    return DropdownMenuItem(
                      value: e,
                      child: Text(e),
                    );
                  }).toList(),
                  onChanged: (val) {
                    setState(() {
                      accessLevel = val;
                    });
                  },
                ),
              ),
            ),
            if (accessError != "")
              Text(
                accessError,
                style: TextStyle(color: Colors.red),
              ),
            if (accessLevel == "Gate User") ...[
              Text(
                isArabic ? "المنصب" : "Position",
              ),
              Container(
                margin: EdgeInsets.only(top: 8, bottom: 30),
                padding: EdgeInsets.symmetric(horizontal: 15),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(15),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black12,
                      blurRadius: 10,
                      offset: Offset(0, 4),
                    )
                  ],
                ),
                child: DropdownButtonHideUnderline(
                  child: DropdownButton<String>(
                    value: position,
                    hint: Text(
                      isArabic ? "المسجل" : "Registrar",
                    ),
                    isExpanded: true,
                    items: positions.map((e) {
                      return DropdownMenuItem(
                        value: e,
                        child: Text(e),
                      );
                    }).toList(),
                    onChanged: (val) {
                      setState(() {
                        position = val;
                      });
                    },
                  ),
                ),
              ),
            ],
            Center(
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.black,
                  padding: EdgeInsets.symmetric(
                    horizontal: 70,
                    vertical: 15,
                  ),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                onPressed: createAccount,
                child: Text(
                  isArabic ? "إنشاء حساب" : "Create account",
                  style: TextStyle(
                    fontSize: 18,
                    color: Colors.white,
                  ),
                ),
              ),
            ),
            SizedBox(height: 30),
            Center(
              child: GestureDetector(
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => AdminListUsers(),
                    ),
                  );
                },
                child: Text(
                  isArabic
                      ? "الانتقال إلى صفحة قائمة المستخدمين"
                      : "Go to for admin page-list of user :",
                  style: TextStyle(
                    color: Colors.blue,
                    fontSize: 16,
                    decoration: TextDecoration.underline,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

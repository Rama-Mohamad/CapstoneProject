const canvas = document.getElementById("gateChart");

if (canvas) {
  const ctx = canvas.getContext("2d");

  const days = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
  const values = [120, 180, 150, 220, 260, 200, 300];

  const maxValue = Math.max(...values);
  const chartHeight = 200;
  const startX = 60;
  const startY = 230;
  const barWidth = 55;
  const gap = 55;

  ctx.clearRect(0, 0, canvas.width, canvas.height);

  ctx.font = "14px Arial";
  ctx.fillStyle = "#64748b";

  for (let i = 0; i < days.length; i++) {
    const barHeight = (values[i] / maxValue) * chartHeight;
    const x = startX + i * (barWidth + gap);
    const y = startY - barHeight;

    ctx.fillStyle = "#2563eb";
    ctx.fillRect(x, y, barWidth, barHeight);

    ctx.fillStyle = "#0f172a";
    ctx.fillText(values[i], x + 12, y - 10);

    ctx.fillStyle = "#64748b";
    ctx.fillText(days[i], x + 12, startY + 25);
  }

  ctx.beginPath();
  ctx.moveTo(40, startY);
  ctx.lineTo(850, startY);
  ctx.strokeStyle = "#cbd5e1";
  ctx.stroke();
}

function openGate() {
  const status = document.getElementById("gateStatus");

  if (status) {
    status.textContent = "OPEN";
    status.style.color = "#059669";
    alert("Gate opened successfully");
  }
}

function closeGate() {
  const status = document.getElementById("gateStatus");

  if (status) {
    status.textContent = "CLOSED";
    status.style.color = "#dc2626";
    alert("Gate closed successfully");
  }
}

function addUser() {
  const table = document.getElementById("usersTable");

  if (table) {
    const tbody = table.querySelector("tbody");
    const rowCount = tbody.rows.length + 1;

    const name = prompt("Enter user name:");
    const email = prompt("Enter user email:");
    const role = prompt("Enter user role:");

    if (name && email && role) {
      const newRow = tbody.insertRow();

      newRow.innerHTML = `
        <td>${rowCount}</td>
        <td>${name}</td>
        <td>${email}</td>
        <td>${role}</td>
        <td><span class="badge success">Active</span></td>
        <td>May 11, 2026 10:55 AM</td>
        <td>
          <button class="small-btn edit" onclick="editUser(this)">✎</button>
          <button class="small-btn delete" onclick="deleteUser(this)">🗑</button>
        </td>
      `;
    }
  }
}

function editUser(button) {
  const row = button.closest("tr");
  const nameCell = row.cells[1];
  const emailCell = row.cells[2];
  const roleCell = row.cells[3];

  const newName = prompt("Edit user name:", nameCell.textContent);
  const newEmail = prompt("Edit user email:", emailCell.textContent);
  const newRole = prompt("Edit user role:", roleCell.textContent);

  if (newName && newEmail && newRole) {
    nameCell.textContent = newName;
    emailCell.textContent = newEmail;
    roleCell.textContent = newRole;
  }
}

function deleteUser(button) {
  const confirmDelete = confirm("Are you sure you want to delete this user?");

  if (confirmDelete) {
    button.closest("tr").remove();
  }
}

function saveSettings() {
  alert("Settings saved successfully");
}
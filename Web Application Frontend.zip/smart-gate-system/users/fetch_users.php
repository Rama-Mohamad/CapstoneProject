<?php
include('../config/db.php');

$result = $conn->query("SELECT id, full_name, email, role, status, created_at FROM users ORDER BY created_at DESC");
$users = [];

while ($row = $result->fetch_assoc()) {
    $users[] = $row;
}

echo json_encode($users);
?>
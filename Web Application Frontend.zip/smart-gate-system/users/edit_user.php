<?php
include('../config/db.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $id = $_POST['id'];
    $full_name = trim($_POST['full_name']);
    $email = trim($_POST['email']);
    $role = $_POST['role'];
    $status = $_POST['status'];

    // VALIDATION (must come after variables)
    if (empty($full_name) || empty($email) || empty($role)) {
        die("All fields are required.");
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        die("Invalid email format.");
    }

    // UPDATE DATABASE
    $stmt = $conn->prepare("
        UPDATE users 
        SET full_name = ?, email = ?, role = ?, status = ?
        WHERE id = ?
    ");
    $stmt->bind_param("ssssi", $full_name, $email, $role, $status, $id);

    echo $stmt->execute() ? "User updated successfully." : "Failed to update user.";
}
?>
<?php
include('../config/db.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // GET DATA FIRST
    $full_name = trim($_POST['full_name']);
    $email = trim($_POST['email']);
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $role = $_POST['role'];

    // VALIDATION (NOW VARIABLES EXIST)
    if (empty($full_name) || empty($email) || empty($role)) {
        die("All fields are required.");
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        die("Invalid email format.");
    }

    // INSERT INTO DATABASE
    $stmt = $conn->prepare("INSERT INTO users (full_name, email, password, role) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $full_name, $email, $password, $role);

    echo $stmt->execute() ? "User added successfully." : "Failed to add user.";
}
?>
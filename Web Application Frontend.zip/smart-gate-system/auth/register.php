<?php
include('../config/db.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $full_name = trim($_POST['full_name']);
    $email = trim($_POST['email']);
    $password_raw = $_POST['password'];

    // ===== VALIDATION =====

    if (empty($full_name) || empty($email) || empty($password_raw)) {
        die("All fields are required.");
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        die("Invalid email format.");
    }

    if (strlen($password_raw) < 6) {
        die("Password must be at least 6 characters.");
    }

    // ===== CHECK DUPLICATE EMAIL =====

    $check = $conn->prepare("SELECT id FROM users WHERE email = ?");
    $check->bind_param("s", $email);
    $check->execute();
    $check->store_result();

    if ($check->num_rows > 0) {
        die("Email already exists.");
    }

    // ===== INSERT USER =====

    $password = password_hash($password_raw, PASSWORD_DEFAULT);

    $stmt = $conn->prepare("INSERT INTO users (full_name, email, password) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $full_name, $email, $password);

    if ($stmt->execute()) {
        header("Location: ../../../frontend/pages/login.html");
        exit();
    } else {
        die("Registration failed.");
    }
}
?>

Bawaba 2030 Smart Gate System – Web Prototype

## Overview

This web-based administrative prototype was developed as part of the Bawaba 2030 Smart Gate System project. The prototype was created to demonstrate a number of administrative functions including user authentication, user management, gate monitoring, and viewing access logs.

The prototype was developed using HTML, CSS, and JavaScript for the user interfaces, PHP for backend processing, and MySQL for data storage. A simple Django-based API was also implemented to demonstrate how system log data can be provided through a backend endpoint.

The prototype was tested locally using the XAMPP environment and serves as a proof-of-concept for the administrative side of the Smart Gate System rather than a complete production-ready web application.

⸻
## System Workflow

The web prototype consists of three main components:

Frontend interfaces developed using HTML, CSS, and JavaScript.

Backend modules developed using PHP.

MySQL database used for storing users and system records.

When a user performs an action through the web interface, the request is processed by the corresponding PHP module. The PHP code communicates with the MySQL database to retrieve, validate, insert, or update data as required. The resulting information is then returned to the interface and displayed to the user.

In addition, a simple Django-based API was implemented to demonstrate backend endpoint functionality and JSON-based data responses.

⸻
## Prototype Features
Authentication

User Login

User Registration

Input Validation

Session Management
User Management

View Users

Add Users

Edit Users

Delete Users
Gate Monitoring

Open Gate Status Demonstration

Close Gate Status Demonstration

Gate Status Monitoring
Logs Demonstration

Access Log Viewing

Activity Log Display

Django API Log Endpoint

⸻
## Technologies Used
Frontend

HTML5

CSS3

JavaScript
Backend

PHP

Django
Database

MySQL
Development Tools

Visual Studio Code

XAMPP

phpMyAdmin

⸻
## Database Structure

The MySQL database used in the prototype contains the following tables:

users

access_logs

gate_logs

gate_status

settings

⸻
Running the Prototype
Step 1: Start XAMPP

Start the following services:

Apache

MySQL
Step 2: Configure the Database

Create a database named:

smart_gate_system

Import the provided SQL database file if required.
Step 3: Place the Project Folder

Copy the project folder into:

C:\xampp\htdocs\
Step 4: Open the Prototype

Open the project through a web browser using the local server environment.
Step 5: Run the Django API (Optional)

Open a terminal inside the Django project folder and run:

python manage.py runserver

The API can then be accessed locally through the configured endpoint.

## Prototype Purpose

The purpose of this prototype is to demonstrate how administrative functions of the Smart Gate System can be implemented using web technologies. The prototype focuses on authentication, user management, database interaction, gate monitoring concepts, and backend communication within a local development environment.
 

<?php
include('../config/db.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $setting_name = $_POST['setting_name'];
    $setting_value = $_POST['setting_value'];

    $stmt = $conn->prepare("
        INSERT INTO settings (setting_name, setting_value)
        VALUES (?, ?)
        ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)
    ");
    $stmt->bind_param("ss", $setting_name, $setting_value);

    echo $stmt->execute() ? "Settings updated successfully." : "Failed to update settings.";
}
?>
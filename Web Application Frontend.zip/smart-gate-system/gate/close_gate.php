<?php
include('../config/db.php');

if ($conn->query("UPDATE gate_status SET gate_state='closed' WHERE id=1")) {
    echo "Gate closed successfully.";
} else {
    echo "Failed to close gate.";
}
?>
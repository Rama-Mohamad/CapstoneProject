<?php
include('../config/db.php');

$result = $conn->query("SELECT gate_state, updated_at FROM gate_status WHERE id=1");
echo json_encode($result->fetch_assoc());
?>
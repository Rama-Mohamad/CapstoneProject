<?php
include('../config/db.php');

if ($conn->query("UPDATE gate_status SET gate_state='open' WHERE id=1")) {
    echo "Gate opened successfully.";
} else {
    echo "Failed to open gate.";
}
?>
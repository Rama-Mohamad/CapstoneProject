from django.http import JsonResponse

def logs(request):
    data = [
        {"id": 1, "action": "Gate Opened"},
        {"id": 2, "action": "User Added"},
        {"id": 3, "action": "Gate Closed"}
    ]
    return JsonResponse(data, safe=False)